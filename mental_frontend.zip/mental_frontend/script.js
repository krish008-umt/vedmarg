const pages = document.querySelectorAll(".page");
const navBtns = document.querySelectorAll(".nav-btn");
const loginModal = document.getElementById("loginModal");
const loginTrigger = document.getElementById("loginTrigger");
const loginForm = document.getElementById("loginForm");
const streakEl = document.getElementById("streakCount");
const guestInfo = document.querySelector(".guest-info");
const messagesContainer = document.querySelector(".messages");
const sendBtn = document.getElementById("sendBtn");
const textInput = document.getElementById("textInput");

let isLoggedIn = false;
let currentUser = null;
let streakDays = 0;

// === Navigation ===
navBtns.forEach(btn => {
  btn.addEventListener("click", () => {
    const target = btn.dataset.page;

    // If user not logged in and not on chatbot, block navigation
    if (!isLoggedIn && target !== "chatbot") {
      alert("Please login to access this feature.");
      loginModal.classList.remove("hidden");
      return;
    }

    // Update active button and section
    navBtns.forEach(b => b.classList.remove("active"));
    btn.classList.add("active");
    pages.forEach(p => p.classList.remove("active"));
    document.getElementById(target).classList.add("active");
  });
});

// === Login Modal ===
loginTrigger.addEventListener("click", () => {
  loginModal.classList.remove("hidden");
});

loginForm.addEventListener("submit", (e) => {
  e.preventDefault();
  const form = new FormData(loginForm);
  currentUser = {
    name: form.get("name"),
    age: form.get("age"),
    goals: form.get("goals"),
    concerns: form.get("concerns")
  };
  document.getElementById("pName").textContent = currentUser.name;
  document.getElementById("pAge").textContent = currentUser.age;
  document.getElementById("pGoals").textContent = currentUser.goals;
  document.getElementById("pConcerns").textContent = currentUser.concerns;

  isLoggedIn = true;
  streakDays++;
  streakEl.textContent = streakDays;
  guestInfo.textContent = "Welcome back 🌸";
  loginModal.classList.add("hidden");
  alert(`Welcome ${currentUser.name}!`);
});

// === Chatbot ===
sendBtn.addEventListener("click", () => {
  // ✅ Block sending messages if not logged in
  if (!isLoggedIn) {
    alert("Please login to chat with the AI companion.");
    loginModal.classList.remove("hidden");
    return;
  }

  const text = textInput.value.trim();
  if (!text) return;

  addMessage("user", text);
  textInput.value = "";
  simulateResponse(text);
});

function addMessage(type, text) {
  const div = document.createElement("div");
  div.classList.add("msg", type);
  div.textContent = text;
  messagesContainer.appendChild(div);
  messagesContainer.scrollTop = messagesContainer.scrollHeight;
}

function simulateResponse(text) {
  addMessage("system", "Analyzing your mood...");
  setTimeout(() => {
    const emotions = ["happy", "sad", "anxious", "stressed", "neutral"];
    const emotion = emotions[Math.floor(Math.random() * emotions.length)];
    const confidence = (Math.random() * 40 + 60).toFixed(1);
    const reply = getResponse(emotion);
    addMessage("bot", `Detected emotion: ${emotion} (${confidence}%)\n${reply}`);
  }, 1500);
}

function getResponse(emotion) {
  const responses = {
    happy: "🌞 That’s wonderful! Keep that energy flowing.",
    sad: "💜 It's okay to feel down. Try writing your thoughts in a journal.",
    anxious: "🌿 Deep breaths — in for 4, out for 6. You’re safe here.",
    stressed: "💫 Take a short break and stretch a bit.",
    neutral: "✨ Let's focus on something positive you achieved today!"
  };
  return responses[emotion];
}
