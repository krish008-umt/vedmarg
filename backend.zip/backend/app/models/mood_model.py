from pydantic import BaseModel, Field
from typing import Optional
from datetime import datetime
from bson import ObjectId


class MoodEntry(BaseModel):
    id: Optional[str] = Field(default=None, alias="_id")
    user_id: str
    emotion: str
    confidence: float
    timestamp: datetime = Field(default_factory=datetime.utcnow)

    class Config:
        allow_population_by_field_name = True
        json_encoders = {
            ObjectId: str
        }
