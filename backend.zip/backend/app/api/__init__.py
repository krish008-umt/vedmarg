# This file marks the "api" directory as a Python package.
# You can also place shared API-wide configuration here if needed.

"""
API package that contains all route handlers and dependencies.
"""
