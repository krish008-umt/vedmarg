from fastapi import Depends, HTTPException, Header
from app.config import get_settings, Settings
from app.db.mongodb import get_database
from app.db.vector_db import get_vector_db
from app.utils.logger import logger


def get_settings_dependency() -> Settings:
    """
    Dependency to load application settings.
    """
    return get_settings()


async def db_dependency():
    """
    Dependency to access MongoDB connection.
    """
    try:
        db = await get_database()
        return db
    except Exception as e:
        logger.error(f"Database connection error: {e}")
        raise HTTPException(status_code=500, detail="Database not available")


async def vector_db_dependency():
    """
    Dependency for Vector DB (ChromaDB).
    """
    try:
        vectordb = get_vector_db()
        return vectordb
    except Exception as e:
        logger.error(f"Vector DB error: {e}")
        raise HTTPException(status_code=500, detail="Vector database not available")


async def get_authorization_token(Authorization: str = Header(None)):
    """
    Extract and validate JWT token for protected routes.
    """
    if Authorization is None:
        raise HTTPException(status_code=401, detail="Missing Authorization header")

    token = Authorization.replace("Bearer ", "").strip()

    if not token:
        raise HTTPException(status_code=401, detail="Invalid token format")

    return token
