"""
This package contains all API route handlers for the backend:
- text_input.py
- audio_input.py
- video_input.py
- gemini.py
- mood_history.py
- auth.py
"""

# Expose route modules for optional direct imports
__all__ = [
    "text_input",
    "audio_input",
    "video_input",
    "gemini",
    "mood_history",
    "auth"
]
