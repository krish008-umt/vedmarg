from fastapi import APIRouter, Depends, HTTPException
from app.schemas.user_schema import UserCreateRequest, UserResponse
from app.models.user_model import UserModel
from app.api.dependencies import db_dependency
from app.utils.logger import logger
from bson import ObjectId

router = APIRouter()


@router.post("/auth/register", response_model=UserResponse)
async def register_user(
    request: UserCreateRequest,
    db=Depends(db_dependency)
):
    """
    Creates a new user profile in the database.
    Triggered when user enters details in login modal.
    """
    try:
        user_collection = db["users"]

        # Check if user exists by exact match
        existing_user = await user_collection.find_one({
            "name": request.name,
            "age": request.age
        })

        if existing_user:
            return UserResponse(
                user_id=str(existing_user["_id"]),
                name=existing_user["name"],
                age=existing_user["age"],
                goals=existing_user["goals"],
                concerns=existing_user["concerns"],
            )

        # Create new user
        new_user = UserModel(
            name=request.name,
            age=request.age,
            goals=request.goals,
            concerns=request.concerns
        ).dict()

        result = await user_collection.insert_one(new_user)

        return UserResponse(
            user_id=str(result.inserted_id),
            name=new_user["name"],
            age=new_user["age"],
            goals=new_user["goals"],
            concerns=new_user["concerns"],
        )

    except Exception as e:
        logger.error(f"User registration failed: {e}")
        raise HTTPException(status_code=500, detail="User registration failed")


@router.get("/auth/user/{user_id}", response_model=UserResponse)
async def get_user(
    user_id: str,
    db=Depends(db_dependency)
):
    """
    Fetch user profile.
    Used by frontend when refreshing session.
    """
    try:
        user_collection = db["users"]

        user = await user_collection.find_one({"_id": ObjectId(user_id)})

        if not user:
            raise HTTPException(status_code=404, detail="User not found")

        return UserResponse(
            user_id=str(user["_id"]),
            name=user["name"],
            age=user["age"],
            goals=user["goals"],
            concerns=user["concerns"],
        )

    except Exception as e:
        logger.error(f"User lookup failed: {e}")
        raise HTTPException(status_code=500, detail="Failed to fetch user profile")
