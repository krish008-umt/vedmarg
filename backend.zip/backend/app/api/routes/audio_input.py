from fastapi import APIRouter, File, UploadFile, HTTPException, Depends
from app.schemas.audio_input_schema import AudioEmotionResponse
from app.services.audio_emotion_opensmile import AudioEmotionAnalyzer
from app.services.mood_service import MoodService
from app.api.dependencies import db_dependency
from app.utils.file_utils import save_temp_file
from app.utils.logger import logger

router = APIRouter()


@router.post("/audio", response_model=AudioEmotionResponse)
async def analyze_audio_emotion(
    user_id: str,
    audio_file: UploadFile = File(...),
    db=Depends(db_dependency)
):
    """
    Analyze emotion from audio-only input using OpenSmile feature extraction
    and our emotion inference logic.
    """

    try:
        # 1. Save audio temporarily
        temp_path = save_temp_file(audio_file)

        # 2. Analyze audio emotion
        analyzer = AudioEmotionAnalyzer()
        emotion, confidence = analyzer.predict(temp_path)

        # 3. Save mood history
        mood_service = MoodService(db)
        await mood_service.save_mood_entry(
            user_id=user_id,
            source="audio",
            emotion=emotion,
            confidence=confidence,
            raw_input="AUDIO_FILE"
        )

        # 4. Return response
        return AudioEmotionResponse(
            emotion=emotion,
            confidence=confidence,
            message="Audio emotion analyzed successfully."
        )

    except Exception as e:
        logger.error(f"Audio emotion analysis failed: {e}")
        raise HTTPException(status_code=500, detail="Audio emotion detection failed")
