from fastapi import APIRouter, HTTPException, Depends
from app.schemas.text_input_schema import TextEmotionRequest, TextEmotionResponse
from app.services.text_emotion_model import TextEmotionAnalyzer
from app.services.mood_service import MoodService
from app.api.dependencies import db_dependency
from app.utils.logger import logger

router = APIRouter()


@router.post("/text", response_model=TextEmotionResponse)
async def analyze_text_emotion(
    payload: TextEmotionRequest,
    db=Depends(db_dependency)
):
    """
    Analyze user's text input using the custom trained NLP emotion classifier.
    """

    try:
        # 1. Load text emotion model
        analyzer = TextEmotionAnalyzer()

        # 2. Predict emotion
        emotion, confidence = analyzer.predict(payload.text)

        # 3. Save to mood history
        mood_service = MoodService(db)
        await mood_service.save_mood_entry(
            user_id=payload.user_id,
            source="text",
            emotion=emotion,
            confidence=confidence,
            raw_input=payload.text
        )

        # 4. Return formatted response
        return TextEmotionResponse(
            emotion=emotion,
            confidence=confidence,
            message="Text emotion analyzed successfully."
        )

    except Exception as e:
        logger.error(f"Text emotion analysis failed: {e}")
        raise HTTPException(status_code=500, detail="Text emotion detection failed")
