from fastapi import APIRouter, HTTPException, Depends
from app.schemas.gemini_schema import GeminiRequest, GeminiResponse
from app.services.gemini_service import GeminiChatService
from app.services.rag_service import RAGService
from app.services.mood_service import MoodService
from app.api.dependencies import db_dependency
from app.utils.logger import logger

router = APIRouter()


@router.post("/gemini", response_model=GeminiResponse)
async def chat_with_gemini(
    request: GeminiRequest,
    db=Depends(db_dependency)
):
    """
    This endpoint sends user query + mood context + RAG memory context
    to Gemini to produce an emotionally intelligent, personalized response.
    """

    try:
        user_id = request.user_id
        user_message = request.message

        # ✅ Initialize services
        rag = RAGService(db)
        mood_service = MoodService(db)
        gemini = GeminiChatService()

        # ✅ 1. Get RAG context (documents relevant to the message)
        rag_context = await rag.query_relevant_docs(user_message)

        # ✅ 2. Get recent mood history (last 10 entries)
        mood_history = await mood_service.get_recent_moods(user_id)

        # ✅ 3. Prepare final prompt package for Gemini
        gemini_input = {
            "user_message": user_message,
            "rag_context": rag_context,
            "mood_history": mood_history
        }

        # ✅ 4. Generate Gemini response
        response_text = gemini.generate_response(gemini_input)

        # ✅ 5. Save this chat message into memory (RAG)
        await rag.store_conversation_memory(
            user_id=user_id,
            user_text=user_message,
            assistant_text=response_text
        )

        return GeminiResponse(
            response=response_text,
            mood_used=mood_history,
            rag_used=rag_context
        )

    except Exception as e:
        logger.error(f"Gemini processing failed: {e}")
        raise HTTPException(status_code=500, detail="Gemini processing failed")
