from fastapi import APIRouter, File, UploadFile, HTTPException, Depends
from app.schemas.video_input_schema import VideoEmotionResponse
from app.services.video_emotion_deepface import VideoAudioEmotionService
from app.services.mood_service import MoodService
from app.api.dependencies import db_dependency
from app.utils.file_utils import save_temp_file
from app.utils.logger import logger

router = APIRouter()


@router.post("/video", response_model=VideoEmotionResponse)
async def analyze_video_audio_emotion(
    user_id: str,
    video_file: UploadFile = File(...),
    db=Depends(db_dependency)
):
    """
    Analyze emotion from combined Video + Audio input.
    Extracts:
        - Face emotion (DeepFace)
        - Voice emotion (OpenSmile)
        - Combined final emotion
    """

    try:
        # ✅ 1. Save uploaded video temporarily
        temp_path = save_temp_file(video_file)

        # ✅ 2. Run multimodal analysis service
        analyzer = VideoAudioEmotionService()
        result = analyzer.process_video(temp_path)

        final_emotion = result["combined_emotion"]
        face_emotion = result["face_emotion"]
        voice_emotion = result["voice_emotion"]
        confidence = result["confidence"]

        # ✅ 3. Save emotion to mood history
        mood_service = MoodService(db)
        await mood_service.save_mood_entry(
            user_id=user_id,
            source="video_audio",
            emotion=final_emotion,
            confidence=confidence,
            raw_input="VIDEO_FILE"
        )

        # ✅ 4. Return structured response
        return VideoEmotionResponse(
            combined_emotion=final_emotion,
            face_emotion=face_emotion,
            voice_emotion=voice_emotion,
            confidence=confidence,
            message="Video + audio emotion analyzed successfully."
        )

    except Exception as e:
        logger.error(f"Video+Audio emotion detection failed: {e}")
        raise HTTPException(status_code=500, detail="Video+Audio emotion detection failed")
