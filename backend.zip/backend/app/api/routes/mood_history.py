from fastapi import APIRouter, Depends, HTTPException
from app.schemas.mood_schema import MoodEntryRequest, MoodHistoryResponse
from app.services.mood_service import MoodService
from app.api.dependencies import db_dependency
from app.utils.logger import logger

router = APIRouter()


@router.post("/mood/store")
async def store_mood(
    request: MoodEntryRequest,
    db=Depends(db_dependency)
):
    """
    Stores a single mood/emotion entry for the user.
    This is triggered automatically after emotion detection.
    """
    try:
        mood_service = MoodService(db)

        await mood_service.store_mood(
            user_id=request.user_id,
            emotion=request.emotion,
            confidence=request.confidence
        )

        return {"message": "Mood stored successfully"}

    except Exception as e:
        logger.error(f"Failed to store mood: {e}")
        raise HTTPException(status_code=500, detail="Failed to store mood")


@router.get("/mood/history/{user_id}", response_model=MoodHistoryResponse)
async def get_mood_history(
    user_id: str,
    db=Depends(db_dependency)
):
    """
    Returns the user's recent mood history (default last 7–10 entries).
    Used by Gemini to build emotional context.
    """
    try:
        mood_service = MoodService(db)
        history = await mood_service.get_recent_moods(user_id)

        return MoodHistoryResponse(
            user_id=user_id,
            history=history
        )

    except Exception as e:
        logger.error(f"Failed to fetch mood history: {e}")
        raise HTTPException(status_code=500, detail="Failed to fetch mood history")
