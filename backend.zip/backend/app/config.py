import os
from dotenv import load_dotenv
from functools import lru_cache

load_dotenv()


class Settings:
    # === APP CONFIG ===
    APP_NAME: str = "AI Mental Health Companion Backend"
    VERSION: str = "1.0.0"
    DEBUG: bool = os.getenv("DEBUG", "false").lower() == "true"

    # === DATABASE ===
    MONGO_URI: str = os.getenv("MONGO_URI", "mongodb://localhost:27017")
    MONGO_DB_NAME: str = os.getenv("MONGO_DB_NAME", "mental_health_ai")

    # === VECTOR DB (CHROMA) ===
    CHROMA_PERSIST_DIR: str = os.getenv("CHROMA_PERSIST_DIR", "vector_store/")
    EMBEDDING_MODEL_NAME: str = os.getenv("EMBEDDING_MODEL_NAME", "sentence-transformers/all-mpnet-base-v2")

    # === GEMINI ===
    GEMINI_API_KEY: str = os.getenv("GEMINI_API_KEY")
    GEMINI_MODEL: str = os.getenv("GEMINI_MODEL", "gemini-pro")

    # === SECURITY ===
    SECRET_KEY: str = os.getenv("SECRET_KEY", "super-secret-key")
    JWT_EXPIRY_MINUTES: int = 60 * 24  # 1 day

    # === FILE STORAGE ===
    TEMP_UPLOAD_DIR: str = os.getenv("TEMP_UPLOAD_DIR", "uploads/")


@lru_cache()
def get_settings() -> Settings:
    return Settings()
