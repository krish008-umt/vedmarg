import os
import numpy as np

from app.utils.logger import logger
from app.utils.emotion_utils import normalize_emotion


class TextEmotionModel:
    """
    Wrapper for your custom-trained text emotion classifier.
    
    Supports:
    - TensorFlow SavedModel (.h5, .keras, SavedModel folder)
    - PyTorch (.pt)
    - Any model that returns class probabilities
    
    You will plug in your actual model here.
    """

    def __init__(self):
        self.model = None
        self.model_type = None
        self.labels = ["anger", "fear", "joy", "love", "sadness"]  # adjust if different

        self.load_model()

    # ----------------------------------------------------
    # ✅ Load your custom model
    # ----------------------------------------------------
    def load_model(self):
        try:
            model_path = os.getenv("TEXT_MODEL_PATH", "models/text_model")

            if not os.path.exists(model_path):
                logger.warning("Text model path not found. Using fallback neutral mode.")
                self.model = None
                return

            # ✅ Check if TensorFlow model
            if any(f.endswith((".h5", ".keras")) for f in os.listdir(model_path)) or \
               os.path.isdir(model_path):
                from tensorflow import keras
                self.model = keras.models.load_model(model_path)
                self.model_type = "tensorflow"
                logger.info("✅ Loaded TensorFlow text emotion model.")

            # ✅ Check for PyTorch model
            elif any(f.endswith(".pt") for f in os.listdir(model_path)):
                import torch
                self.model = torch.load(model_path, map_location="cpu")
                self.model_type = "pytorch"
                self.model.eval()
                logger.info("✅ Loaded PyTorch text emotion model.")

            else:
                logger.warning("No valid model file found. Text model disabled.")
                self.model = None

        except Exception as e:
            logger.error(f"❌ Failed to load text emotion model: {e}")
            self.model = None

    # ----------------------------------------------------
    # ✅ Preprocessing (replace with yours)
    # ----------------------------------------------------
    def preprocess(self, text: str):
        """
        Replace this with your tokenizer / vectorization logic.
        """
        try:
            # Basic placeholder: convert to 100-dim vector of char ord values
            # Replace with your actual tokenizer
            vector = np.zeros((1, 100))
            for i, c in enumerate(text[:100]):
                vector[0][i] = ord(c)

            return vector

        except Exception:
            return np.zeros((1, 100))

    # ----------------------------------------------------
    # ✅ Predict Emotion
    # ----------------------------------------------------
    def predict(self, text: str) -> dict:
        if not self.model:
            logger.warning("Text model unavailable. Returning neutral.")
            return {
                "emotion": "neutral",
                "confidence": 0.0
            }

        try:
            x = self.preprocess(text)

            # ✅ TensorFlow model prediction
            if self.model_type == "tensorflow":
                probs = self.model.predict(x)[0]
                emotion_idx = int(np.argmax(probs))
                confidence = float(np.max(probs) * 100)

            # ✅ PyTorch model prediction
            elif self.model_type == "pytorch":
                import torch
                with torch.no_grad():
                    x_tensor = torch.tensor(x).float()
                    output = self.model(x_tensor)
                    probs = torch.softmax(output, dim=1)[0].numpy()
                    emotion_idx = int(np.argmax(probs))
                    confidence = float(np.max(probs) * 100)

            emotion = normalize_emotion(self.labels[emotion_idx])

            return {
                "emotion": emotion,
                "confidence": round(confidence, 1)
            }

        except Exception as e:
            logger.error(f"Text emotion prediction failed: {e}")
            return {
                "emotion": "neutral",
                "confidence": 0.0
            }


# ----------------------------------------------------
# ✅ Export global instance
# ----------------------------------------------------
text_emotion_model = TextEmotionModel()


def analyze_text_emotion(text: str):
    return text_emotion_model.predict(text)
