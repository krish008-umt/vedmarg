from google import genai
from app.config import settings
from app.utils.logger import logger


class EmbeddingService:
    """
    Generates vector embeddings using Gemini API.
    Used for:
    - Storing RAG documents
    - Searching RAG database
    - Embedding user queries
    """

    def __init__(self):
        try:
            self.client = genai.Client(api_key=settings.GEMINI_API_KEY)
            self.model_name = "text-embedding-004"
            logger.info("✅ EmbeddingService initialized.")
        except Exception as e:
            logger.error(f"❌ Failed to initialize EmbeddingService: {e}")

    # -------------------------------------------------------
    # ✅ Generate embeddings
    # -------------------------------------------------------
    def embed(self, text: str):
        """
        Returns a list of floats (embedding vector)
        """
        try:
            response = self.client.embeddings.generate(
                model=self.model_name,
                input=text
            )
            return response.data[0].embedding

        except Exception as e:
            logger.error(f"❌ Embedding generation failed: {e}")
            return []


# -------------------------------------------------------
# ✅ Singleton instance export
# -------------------------------------------------------
embedding_service = EmbeddingService()
