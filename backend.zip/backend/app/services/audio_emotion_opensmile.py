import numpy as np
import opensmile
import librosa
from app.utils.logger import logger
from app.utils.emotion_utils import normalize_emotion


class AudioEmotionService:
    """
    Backend version of your OpenSmile-based voice emotion classifier.
    Accepts uploaded audio files (wav/mp3/m4a), extracts features,
    and classifies using your original rule-based logic.
    """

    def __init__(self):
        try:
            logger.info("Initializing OpenSmile for audio emotion detection...")

            self.smile = opensmile.Smile(
                feature_set=opensmile.FeatureSet.emobase,
                feature_level=opensmile.FeatureLevel.Functionals,
            )

            self.loaded = True
            logger.info("Audio emotion detector initialized.")

        except Exception as e:
            logger.error(f"Failed to initialize OpenSmile: {e}")
            self.smile = None
            self.loaded = False

    # -----------------------------
    # AUDIO FEATURE EXTRACTION
    # -----------------------------
    def extract_features(self, audio_path: str):
        """Extract OpenSmile features from an audio file."""
        try:
            audio, sr = librosa.load(audio_path, sr=16000, mono=True)
            features = self.smile.process_signal(audio, sr)
            return features.iloc[0].to_dict()
        except Exception as e:
            logger.error(f"Feature extraction failed: {e}")
            return None

    # -----------------------------
    # EMOTION DECISION LOGIC (from your code)
    # -----------------------------
    def classify(self, f):
        if not f:
            return "neutral", 0.0

        try:
            pitch_mean = f.get('F0final_sma_amean', 120)
            pitch_std = f.get('F0final_sma_std', 20)
            intensity_mean = f.get('pcm_LOGenergy_sma_amean', 0)
            intensity_std = f.get('pcm_LOGenergy_sma_std', 0)
            spectral_centroid = f.get('spectralCentroid_sma_amean', 0)
            spectral_flux = f.get('spectralFlux_sma_amean', 0)

            emotion_scores = {
                'happy': 0,
                'sad': 0,
                'angry': 0,
                'fear': 0,
                'surprised': 0,
                'neutral': 0
            }

            # happy
            if pitch_mean > 180 and intensity_std < 0.1:
                emotion_scores['happy'] += 3
            if spectral_centroid > 2000:
                emotion_scores['happy'] += 2

            # sad
            if pitch_mean < 100 and intensity_mean < 0.05:
                emotion_scores['sad'] += 3
            if pitch_std < 15:
                emotion_scores['sad'] += 2

            # angry
            if intensity_mean > 0.15 and pitch_std > 40:
                emotion_scores['angry'] += 3
            if spectral_flux > 0.2:
                emotion_scores['angry'] += 2

            # fear
            if pitch_mean > 200 and pitch_std > 30:
                emotion_scores['fear'] += 3
            if spectral_centroid > 2500:
                emotion_scores['fear'] += 2

            # surprised
            if intensity_std > 0.2 and spectral_flux > 0.15:
                emotion_scores['surprised'] += 3

            # neutral
            if (100 <= pitch_mean <= 180 and
                0.05 <= intensity_mean <= 0.1 and
                pitch_std < 25):
                emotion_scores['neutral'] += 3

            dominant = max(emotion_scores, key=emotion_scores.get)
            score = emotion_scores[dominant]
            total = sum(emotion_scores.values()) or 1

            confidence = round((score / total) * 100, 1)

            return normalize_emotion(dominant), confidence

        except Exception as e:
            logger.error(f"Audio emotion classification error: {e}")
            return "neutral", 0.0

    # -----------------------------
    # MAIN PUBLIC FUNCTION
    # -----------------------------
    def analyze_audio_emotion(self, audio_path: str) -> dict:
        """Main entry point for API route."""
        if not self.loaded:
            return {"emotion": "neutral", "confidence": 0}

        features = self.extract_features(audio_path)
        emotion, confidence = self.classify(features)

        return {
            "emotion": emotion,
            "confidence": confidence
        }


# Singleton used by API routes
audio_emotion_service = AudioEmotionService()


def analyze_audio_emotion(audio_path: str):
    """Helper wrapper"""
    return audio_emotion_service.analyze_audio_emotion(audio_path)
