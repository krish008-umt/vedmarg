import os
import google.generativeai as genai
from dotenv import load_dotenv

from app.utils.logger import logger
from app.utils.prompt_utils import build_gemini_prompt


load_dotenv()


class GeminiService:
    """
    Wrapper around the Gemini API.
    Takes structured inputs (emotion, text, RAG docs, etc.)
    and returns a safe, supportive AI response.
    """

    def __init__(self):
        try:
            api_key = os.getenv("GEMINI_API_KEY")
            if not api_key:
                raise ValueError("Gemini API key missing.")

            genai.configure(api_key=api_key)

            self.model = genai.GenerativeModel("gemini-1.5-flash")
            logger.info("✅ Gemini model initialized.")
        except Exception as e:
            logger.error(f"❌ Failed to initialize Gemini model: {e}")
            self.model = None

    # -------------------------------------------------------
    # ✅ Generate AI response
    # -------------------------------------------------------
    def generate_response(
        self,
        text_emotion=None,
        voice_emotion=None,
        face_emotion=None,
        user_message=None,
        rag_documents=None,
        mood_history=None,
        input_type="text"
    ):
        """
        input_type ∈ {"text", "audio", "video"}
        """

        if not self.model:
            return "Error: Gemini model not available."

        # Build the structured prompt
        prompt = build_gemini_prompt(
            text_emotion=text_emotion,
            voice_emotion=voice_emotion,
            face_emotion=face_emotion,
            user_message=user_message,
            rag_documents=rag_documents,
            mood_history=mood_history,
            input_type=input_type
        )

        try:
            response = self.model.generate_content(prompt)
            return response.text
        except Exception as e:
            logger.error(f"❌ Gemini API error: {e}")
            return (
                "I'm here with you. Something went wrong on my end, "
                "but you can continue sharing your thoughts."
            )


# -------------------------------------------------------
# ✅ Export instance
# -------------------------------------------------------
gemini_service = GeminiService()


def generate_gemini_reply(**kwargs):
    """
    Helper wrapper for routes.
    Example call:
        generate_gemini_reply(
            text_emotion='sad',
            user_message='I feel down',
            rag_documents=[...],
            input_type='text'
        )
    """
    return gemini_service.generate_response(**kwargs)
