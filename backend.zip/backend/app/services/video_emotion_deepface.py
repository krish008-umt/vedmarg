import cv2
import numpy as np
import librosa
import opensmile
from deepface import DeepFace

from app.utils.logger import logger
from app.utils.emotion_utils import normalize_emotion


class VideoEmotionService:
    """
    Backend version of your Video + Audio multimodal emotion detector.
    
    Accepts:
      - uploaded video file path
    Extracts:
      - face emotion (DeepFace)
      - voice emotion (OpenSmile)
    Combines:
      - weighted emotion output
    """

    def __init__(self):
        # ✅ Initialize OpenSmile
        try:
            self.smile = opensmile.Smile(
                feature_set=opensmile.FeatureSet.emobase,
                feature_level=opensmile.FeatureLevel.Functionals,
            )
            self.loaded = True
            logger.info("✅ VideoEmotionService initialized successfully.")
        except Exception as e:
            logger.error(f"❌ OpenSmile initialization failed: {e}")
            self.smile = None
            self.loaded = False

    # ----------------------------------------------------
    # 📌 Extract Face Emotion From Video
    # ----------------------------------------------------
    def extract_face_emotion(self, frame):
        try:
            result = DeepFace.analyze(
                img_path=frame,
                actions=["emotion"],
                enforce_detection=False,
                detector_backend="opencv",
                silent=True
            )

            if isinstance(result, list):
                result = result[0]

            face_emotion = result.get("dominant_emotion", "neutral")
            emotion_dict = result.get("emotion", {})

            # confidence = probability of dominant emotion
            confidence = float(emotion_dict.get(face_emotion, 0))

            return normalize_emotion(face_emotion), confidence

        except Exception as e:
            logger.error(f"Face emotion detection failed: {e}")
            return "neutral", 0.0

    # ----------------------------------------------------
    # 📌 Extract Voice Emotion From Video Audio Track
    # ----------------------------------------------------
    def extract_voice_emotion(self, video_path: str):
        try:
            # Extract audio
            audio, sr = librosa.load(video_path, sr=16000, mono=True)

            features = self.smile.process_signal(audio, sr)
            f = features.iloc[0].to_dict()

            # same rule-based logic used in audio-input service
            return self.classify_voice_features(f)

        except Exception as e:
            logger.error(f"Voice extraction failed: {e}")
            return "neutral", 0.0

    # ----------------------------------------------------
    # 📌 Voice classification logic (same as audio service)
    # ----------------------------------------------------
    def classify_voice_features(self, f):
        try:
            pitch_mean = f.get('F0final_sma_amean', 120)
            pitch_std = f.get('F0final_sma_std', 20)
            intensity_mean = f.get('pcm_LOGenergy_sma_amean', 0)
            intensity_std = f.get('pcm_LOGenergy_sma_std', 0)
            spectral_centroid = f.get('spectralCentroid_sma_amean', 0)
            spectral_flux = f.get('spectralFlux_sma_amean', 0)

            scores = {
                'happy': 0,
                'sad': 0,
                'angry': 0,
                'fear': 0,
                'surprised': 0,
                'neutral': 0
            }

            # your original logic…
            if pitch_mean > 180 and intensity_std < 0.1:
                scores['happy'] += 3
            if spectral_centroid > 2000:
                scores['happy'] += 2

            if pitch_mean < 100 and intensity_mean < 0.05:
                scores['sad'] += 3
            if pitch_std < 15:
                scores['sad'] += 2

            if intensity_mean > 0.15 and pitch_std > 40:
                scores['angry'] += 3
            if spectral_flux > 0.2:
                scores['angry'] += 2

            if pitch_mean > 200 and pitch_std > 30:
                scores['fear'] += 3
            if spectral_centroid > 2500:
                scores['fear'] += 2

            if intensity_std > 0.2 and spectral_flux > 0.15:
                scores['surprised'] += 3

            if (100 <= pitch_mean <= 180 and 0.05 <= intensity_mean <= 0.1 and pitch_std < 25):
                scores['neutral'] += 3

            dominant = max(scores, key=scores.get)
            total = sum(scores.values()) or 1
            confidence = round((scores[dominant] / total) * 100, 1)

            return normalize_emotion(dominant), confidence

        except:
            return "neutral", 0.0

    # ----------------------------------------------------
    # 📌 Combine Face + Voice Emotions
    # ----------------------------------------------------
    def combine_emotions(self, face_emotion, face_conf, voice_emotion, voice_conf):
        """
        Weighting:
            Face = 80%
            Voice = 20%
        """

        face_weight = 0.8
        voice_weight = 0.2

        combined = (
            face_conf * face_weight +
            voice_conf * voice_weight
        )

        # Choose emotion from the highest weighted confidence
        final_emotion = (
            face_emotion
            if face_conf * face_weight >= voice_conf * voice_weight
            else voice_emotion
        )

        return normalize_emotion(final_emotion), round(combined, 1)

    # ----------------------------------------------------
    # 📌 Main Function: Analyze Video
    # ----------------------------------------------------
    def analyze_video_emotion(self, video_path: str) -> dict:
        if not self.loaded:
            logger.warning("VideoEmotionService not loaded. Returning neutral.")
            return {"emotion": "neutral", "confidence": 0}

        # 1️⃣ Extract face emotion from first clear frame
        cap = cv2.VideoCapture(video_path)
        ret, frame = cap.read()
        cap.release()

        if not ret:
            logger.error("Could not read video frame.")
            return {"emotion": "neutral", "confidence": 0}

        face_emotion, face_conf = self.extract_face_emotion(frame)

        # 2️⃣ Extract voice emotion using OpenSmile
        voice_emotion, voice_conf = self.extract_voice_emotion(video_path)

        # 3️⃣ Combine both
        final_emotion, final_confidence = self.combine_emotions(
            face_emotion, face_conf,
            voice_emotion, voice_conf
        )

        return {
            "emotion": final_emotion,
            "confidence": final_confidence,
            "face_emotion": face_emotion,
            "voice_emotion": voice_emotion
        }


# Singleton for import everywhere
video_emotion_service = VideoEmotionService()


def analyze_video_emotion(video_path: str):
    return video_emotion_service.analyze_video_emotion(video_path)
