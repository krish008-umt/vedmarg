from typing import List
from app.services.embedding_service import embedding_service
from app.db.vector_db import vector_db
from app.utils.logger import logger


class RAGService:
    """
    Retrieves relevant documents from the vector DB
    using semantic search.
    """

    def __init__(self):
        logger.info("✅ RAGService initialized.")

    # -------------------------------------------------------
    # ✅ Store a document in the vector DB
    # -------------------------------------------------------
    async def add_document(self, doc_id: str, text: str, metadata: dict = None):
        try:
            embedding = embedding_service.embed(text)
            vector_db.add(
                ids=[doc_id],
                embeddings=[embedding],
                metadatas=[metadata or {}],
                documents=[text]
            )
        except Exception as e:
            logger.error(f"❌ Failed to add RAG document: {e}")

    # -------------------------------------------------------
    # ✅ Retrieve relevant mental-health content
    # -------------------------------------------------------
    async def retrieve(self, query: str, top_k: int = 5) -> List[str]:
        """
        Searches vector DB using semantic similarity.

        Returns: a list of raw text documents,
        ready to insert into Gemini prompt.
        """
        try:
            query_embedding = embedding_service.embed(query)

            results = vector_db.search(
                query_embedding=query_embedding,
                top_k=top_k
            )

            if not results:
                return []

            # Extract only text documents
            documents = [doc.get("document") for doc in results if doc.get("document")]

            return documents

        except Exception as e:
            logger.error(f"❌ RAG retrieval failed: {e}")
            return []


# -------------------------------------------------------
# ✅ Singleton instance export
# -------------------------------------------------------
rag_service = RAGService()
