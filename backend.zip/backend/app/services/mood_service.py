from datetime import datetime, timedelta
from app.db.mongodb import mongo_db
from app.utils.logger import logger


class MoodService:
    """
    Handles storage and retrieval of user mood/emotion history.
    """

    COLLECTION = "mood_history"

    # ------------------------------------------------------------
    # ✅ Save detected mood
    # ------------------------------------------------------------
    def save_mood(self, user_id: str, source: str, emotion: str, confidence: float):
        """
        Stores one mood entry:
        - source = "text" / "audio" / "video"
        - emotion = final detected emotion
        """
        try:
            doc = {
                "user_id": user_id,
                "source": source,
                "emotion": emotion,
                "confidence": confidence,
                "timestamp": datetime.utcnow()
            }

            mongo_db[self.COLLECTION].insert_one(doc)
            logger.info(f"✅ Mood saved for user {user_id}: {emotion}")

            return True

        except Exception as e:
            logger.error(f"❌ Failed to save mood: {e}")
            return False

    # ------------------------------------------------------------
    # ✅ Get last 7-day mood history
    # ------------------------------------------------------------
    def get_last_7_days(self, user_id: str):
        """
        Returns a list of entries from the last 7 days.
        Used inside gemini prompt builder.
        """
        try:
            seven_days_ago = datetime.utcnow() - timedelta(days=7)

            cursor = mongo_db[self.COLLECTION].find(
                {"user_id": user_id, "timestamp": {"$gte": seven_days_ago}}
            ).sort("timestamp", -1)

            history = [
                {
                    "emotion": doc["emotion"],
                    "confidence": doc["confidence"],
                    "source": doc["source"],
                    "timestamp": doc["timestamp"].isoformat()
                }
                for doc in cursor
            ]

            return history

        except Exception as e:
            logger.error(f"❌ Failed to fetch mood history: {e}")
            return []

    # ------------------------------------------------------------
    # ✅ Format mood history for Gemini prompt
    # ------------------------------------------------------------
    def format_history_for_prompt(self, mood_entries: list) -> str:
        """
        Converts mood entries → readable text block for the Gemini prompt.
        """
        if not mood_entries:
            return "No mood history available."

        formatted = []
        for m in mood_entries:
            formatted.append(
                f"- {m['timestamp']}: {m['emotion']} ({m['confidence']}%, {m['source']})"
            )

        return "\n".join(formatted)


# ------------------------------------------------------------
# ✅ Singleton Instance
# ------------------------------------------------------------
mood_service = MoodService()
