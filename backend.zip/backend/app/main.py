from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.api.routes.text_input import router as text_router
from app.api.routes.audio_input import router as audio_router
from app.api.routes.video_input import router as video_router
from app.api.routes.gemini import router as gemini_router
from app.api.routes.mood_history import router as mood_router
from app.api.routes.auth import router as auth_router

from app.db.init_collections import init_database
from app.middleware.auth_middleware import AuthMiddleware


def create_app() -> FastAPI:
    """Factory function to create the FastAPI application."""

    app = FastAPI(
        title="AI Mental Health Companion",
        version="1.0.0",
        description="Backend for Emotion Detection + RAG + Gemini Chat"
    )

    # CORS for frontend
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],  # change to specific domain in production
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # Custom middleware
    app.add_middleware(AuthMiddleware)

    # Routes
    app.include_router(auth_router, prefix="/auth", tags=["Authentication"])
    app.include_router(text_router, prefix="/emotion", tags=["Text Emotion"])
    app.include_router(audio_router, prefix="/emotion", tags=["Audio Emotion"])
    app.include_router(video_router, prefix="/emotion", tags=["Video Emotion"])
    app.include_router(gemini_router, prefix="/chat", tags=["Gemini AI"])
    app.include_router(mood_router, prefix="/mood", tags=["Mood History"])

    @app.on_event("startup")
    async def startup_event():
        """Initialize database and vectorDB on app startup."""
        await init_database()

    return app


app = create_app()
