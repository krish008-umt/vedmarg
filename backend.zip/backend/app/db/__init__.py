# Marks this directory as a Python package.
# Shared database objects can be imported here if needed in future.

from .mongodb import get_database
from .vector_db import get_vector_db
