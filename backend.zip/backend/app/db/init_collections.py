from app.db.mongodb import get_database
from app.config import settings


def init_mongo_collections():
    """
    Ensure all required MongoDB collections exist and create indexes.
    Called once during FastAPI startup.
    """
    db = get_database()

    # === Users Collection ===
    users = db["users"]
    users.create_index("user_id", unique=True)
    users.create_index("email", unique=True)

    # === Mood History Collection ===
    moods = db["mood_history"]
    moods.create_index("user_id")
    moods.create_index("timestamp")

    # === RAG Documents Collection ===
    rag_docs = db["rag_documents"]
    rag_docs.create_index("doc_id", unique=True)
    rag_docs.create_index("tags")

    print("✅ MongoDB collections initialized.")
