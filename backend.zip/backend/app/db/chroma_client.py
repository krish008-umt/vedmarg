# backend/app/db/chroma_client.py
"""
ChromaDB vector database setup for RAG.
- Initializes Chroma client and collection
- Provides add_documents(...) and retrieve_documents(...) helpers
Notes:
- Expects an async embed_text(texts: List[str]) -> List[List[float]] function
  in app.services.embedding_service
- Uses settings.CHROMA_DB_PATH from app.config
"""

from typing import List, Dict, Any
import logging

try:
    import chromadb
    from chromadb.config import Settings as ChromaSettings
except Exception as e:
    chromadb = None
    ChromaSettings = None

from app.config import settings

logger = logging.getLogger("chroma_client")
logger.setLevel(logging.INFO)

# Defensive: require chromadb installed
if chromadb is None:
    logger.warning("chromadb is not installed. Please install chromadb to use RAG retrieval.")
    # Provide a simple None-collection fallback to avoid import errors elsewhere
    collection = None
else:
    # Initialize Chroma client with persist directory from settings
    chroma_client = chromadb.Client(
        ChromaSettings(
            persist_directory=settings.CHROMA_DB_PATH,
            chroma_db_impl="duckdb+parquet"
        )
    )

    # Create or load collection
    collection = chroma_client.get_or_create_collection(
        name="mental_health_knowledge_base",
        metadata={"hnsw:space": "cosine"}
    )


# Try to import your embedding function (async)
try:
    from app.services.embedding_service import embed_text  # should be async
except Exception as e:
    embed_text = None
    logger.warning("embed_text not available from app.services.embedding_service: %s", e)


async def add_documents(docs: List[Dict[str, Any]]):
    """
    Add documents to the Chroma collection.
    docs: list of {"id": str, "text": str, "source": str (optional)}
    """
    if collection is None:
        raise RuntimeError("Chroma collection not initialized (chromadb missing)")

    if embed_text is None:
        raise RuntimeError("Embedding service not available (embed_text missing)")

    ids = [d["id"] for d in docs]
    texts = [d["text"] for d in docs]
    metadatas = [{"source": d.get("source", "unknown")} for d in docs]

    # embed_text expected to be async and return list of embeddings
    embeddings = await embed_text(texts)

    # add to collection
    collection.add(
        ids=ids,
        documents=texts,
        metadatas=metadatas,
        embeddings=embeddings
    )
    # persist to disk
    try:
        chroma_client.persist()
    except Exception:
        # older chromadb clients may not have persist or may auto-persist
        logger.debug("chroma_client.persist() not available or failed; skipping persist.")


async def retrieve_documents(query: str, k: int = 4) -> List[Dict[str, Any]]:
    """
    Retrieve top-k relevant documents for a query.
    Returns list of {"id": id, "text": text, "metadata": {...}, "distance": float (if available)}
    """
    if collection is None:
        raise RuntimeError("Chroma collection not initialized (chromadb missing)")

    if embed_text is None:
        raise RuntimeError("Embedding service not available (embed_text missing)")

    query_embedding = (await embed_text([query]))[0]

    # Query chroma
    results = collection.query(
        query_embeddings=[query_embedding],
        n_results=k,
        include=["documents", "metadatas", "ids", "distances"]
    )

    retrieved = []
    # results format: dict of lists for each returned field
    try:
        docs = results.get("documents", [[]])[0]
        metas = results.get("metadatas", [[]])[0]
        ids = results.get("ids", [[]])[0]
        dists = results.get("distances", [[]])[0] if "distances" in results else [None] * len(docs)

        for i, txt in enumerate(docs):
            retrieved.append({
                "id": ids[i] if i < len(ids) else str(i),
                "text": txt,
                "metadata": metas[i] if i < len(metas) else {},
                "distance": float(dists[i]) if (dists and i < len(dists) and dists[i] is not None) else None
            })
    except Exception as e:
        logger.exception("Error parsing chroma query results: %s", e)

    return retrieved
