from motor.motor_asyncio import AsyncIOMotorClient
from fastapi import Depends
from app.config import settings

client = None
database = None


def init_mongodb():
    """
    Initialize MongoDB connection once at startup.
    Called from main.py
    """
    global client, database

    client = AsyncIOMotorClient(settings.MONGODB_URI)
    database = client[settings.MONGODB_NAME]
    return database


def get_database():
    """
    FastAPI dependency to inject DB instance into routes.
    """
    return database
