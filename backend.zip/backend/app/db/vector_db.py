import chromadb
from chromadb.config import Settings
from app.config import settings

chroma_client = None
rag_collection = None


def init_vector_db():
    """
    Initialize Chroma vector database.
    Called once during FastAPI startup.
    """
    global chroma_client, rag_collection

    chroma_client = chromadb.Client(
        Settings(
            chroma_db_impl="duckdb+parquet",
            persist_directory=settings.CHROMA_DB_PATH
        )
    )

    rag_collection = chroma_client.get_or_create_collection(
        name="rag_documents",
        metadata={"hnsw:space": "cosine"}
    )

    return ragma_collection


def get_vector_db():
    """
    Returns the active RAG collection.
    """
    return rag_collection
